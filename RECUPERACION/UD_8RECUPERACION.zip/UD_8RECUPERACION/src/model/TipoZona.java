package model;

public enum TipoZona {
	ASEOS, DORMITORIOS, PATIOS, OTRO
}
