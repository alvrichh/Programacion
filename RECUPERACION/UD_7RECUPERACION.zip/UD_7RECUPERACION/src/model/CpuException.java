package model;

@SuppressWarnings("serial")
public class CpuException extends ComponenteException {

	public CpuException(String mensaje) {
		super(mensaje);
	}
	
	

}
