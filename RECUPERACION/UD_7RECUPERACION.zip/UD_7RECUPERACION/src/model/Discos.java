package model;

public enum Discos {
	SSD, HD

}
