package model;

@SuppressWarnings("serial")
public class DiscosException extends ComponenteException {

	public DiscosException(String mensaje) {
		super(mensaje);
	}
	
	

}
