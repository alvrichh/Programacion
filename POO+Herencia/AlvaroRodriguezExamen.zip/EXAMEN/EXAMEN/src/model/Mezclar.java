package model;

public interface Mezclar {

    void mezclarConMaterial(Material material);

}
