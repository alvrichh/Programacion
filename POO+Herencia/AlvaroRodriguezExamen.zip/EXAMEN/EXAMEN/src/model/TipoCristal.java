package model;

public enum TipoCristal {
	TRANSPARENTE, TRANSLUCIDO

}
