package model;

public enum Tipo {

	BAÑOS, DORMITORIOS, PATIOS, OTRO
}
