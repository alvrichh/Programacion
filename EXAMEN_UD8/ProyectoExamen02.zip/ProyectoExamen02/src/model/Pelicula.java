package model;

public class Pelicula {

}
